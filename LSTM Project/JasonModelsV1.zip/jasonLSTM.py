import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input, Concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,confusion_matrix
)
from copy import deepcopy
import shap


from sklearn.utils import class_weight

import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import t


def permutation_importance_longitudinal(model, X_ts, X_cross, y_true, ts_features, metric_func, baseline_score):
    importances = {}

    for i, feature in enumerate(ts_features):
        X_ts_shuffled = deepcopy(X_ts)
        # Shuffle the i-th feature across all samples, preserving time steps
        shuffled_values = deepcopy(X_ts[:, :, i])
        np.random.shuffle(shuffled_values)  # shuffles across samples, not time
        X_ts_shuffled[:, :, i] = shuffled_values

        y_pred_probs = model.predict([X_ts_shuffled, X_cross]).flatten()

        if np.isnan(y_pred_probs).any():
            importance = 0
        else:
            y_pred_classes = (y_pred_probs >= 0.5).astype(int)
            new_score = metric_func(y_true, y_pred_classes)
            importance = baseline_score - new_score

        importances[feature] = importance

    return importances


def permutation_importance(model, X_ts, X_cross, y_true, cross_features, metric_func, baseline_score):
    importances = {}

    for i, feature in enumerate(cross_features):
        X_cross_shuffled = deepcopy(X_cross)
        np.random.shuffle(X_cross_shuffled[:, i])
        y_pred_probs = model.predict([X_ts, X_cross_shuffled]).flatten()

        if np.isnan(y_pred_probs).any():
            importance = 0
        else:
            # Convert probabilities to binary predictions for metrics like accuracy
            y_pred_classes = (y_pred_probs >= 0.5).astype(int)
            new_score = metric_func(y_true, y_pred_classes)
            importance = baseline_score - new_score

        importances[feature] = importance

    return importances


# ===========================
# Load and preprocess dataset
# ===========================
df = pd.read_csv('for_JS_final_withgroup.csv')

# Extract numeric site ID from 'site_id_l.baseline_year_1_arm_1'
df['site'] = df['site_id_l.baseline_year_1_arm_1'].str.extract(r'(\d+)$').astype(int)

# Define features for each timepoint
features_baseline = [
    'interview_age.baseline_year_1_arm_1',
    'KSADSintern.baseline_year_1_arm_1',
    'nihtbx_cryst_agecorrected.baseline_year_1_arm_1', 
    'ACEs.baseline_year_1_arm_1',
    'avgPFCthick_QA.baseline_year_1_arm_1',
    'rsfmri_c_ngd_cgc_ngd_cgc_QA.baseline_year_1_arm_1',
    'rsfmri_c_ngd_dt_ngd_dt_QA.baseline_year_1_arm_1'
]

features_followup = [
    'interview_age.2_year_follow_up_y_arm_1',
    'KSADSintern.2_year_follow_up_y_arm_1',
    'nihtbx_cryst_agecorrected.2_year_follow_up_y_arm_1',
    'ACEs.2_year_follow_up_y_arm_1',
    'avgPFCthick_QA.2_year_follow_up_y_arm_1',
    'rsfmri_c_ngd_cgc_ngd_cgc_QA.2_year_follow_up_y_arm_1',
    'rsfmri_c_ngd_dt_ngd_dt_QA.2_year_follow_up_y_arm_1',
]

features_all_time = features_baseline + features_followup

# Define cross-sectional features: all other numeric columns not in features_all_time or site/group columns
cross_sectional_features = [
    'rel_family_id',
    'demo_sex_v2',
    'race_ethnicity',
    'acs_raked_propensity_score',
    'speechdelays',
    'motordelays',
    'fam_history_8_yes_no',
    ]
# ========================
# Clean data
# ========================
for col in features_all_time + cross_sectional_features:
    df[col] = df[col].astype(str).str.strip()
    df.loc[df[col] == '', col] = np.nan
    df[col] = pd.to_numeric(df[col], errors='coerce')

df.dropna(subset=features_all_time + ['group_PDvLP_3timepoint'], inplace=True)

print(f"Total samples after cleaning: {len(df)}")

# ===============================
# Leave-One-Site-Out Cross-Validation
# ===============================
site_ids = df['site'].unique()
site_metrics = []
all_cross_importances = []
all_long_importances = []


for test_site in site_ids:
    print(f"\n==== Testing on site {test_site} ====")

    df_train = df[df['site'] != test_site]
    df_test = df[df['site'] == test_site]

    if df_train.empty or df_test.empty:
        print(f"Skipping site {test_site} due to empty split.")
        continue

    # Build sequences for training (time series)
    X_train_ts, y_train = [], []
    for _, row in df_train.iterrows():
        baseline = row[features_baseline].values.astype(np.float32)
        followup = row[features_followup].values.astype(np.float32)
        if baseline.shape != followup.shape:
            continue
        seq = np.stack([baseline, followup])
        X_train_ts.append(seq)
        y_train.append(row['group_PDvLP_3timepoint'])

    # Build sequences for testing (time series)
    X_test_ts, y_test = [], []
    for _, row in df_test.iterrows():
        baseline = row[features_baseline].values.astype(np.float32)
        followup = row[features_followup].values.astype(np.float32)
        if baseline.shape != followup.shape:
            continue
        seq = np.stack([baseline, followup])
        X_test_ts.append(seq)
        y_test.append(row['group_PDvLP_3timepoint'])

    X_train_ts = np.array(X_train_ts)
    X_test_ts = np.array(X_test_ts)
    y_train = np.array(y_train).astype(int)
    y_test = np.array(y_test).astype(int)

    if len(X_train_ts) == 0 or len(X_test_ts) == 0:
        print(f"Skipping site {test_site} due to no valid samples.")
        continue

    # Build cross-sectional features for train and test
    X_train_cross = df_train[cross_sectional_features].copy()
    X_test_cross = df_test[cross_sectional_features].copy()

    # Fill missing cross-sectional data with median of train set
    X_train_cross.fillna(X_train_cross.median(), inplace=True)
    X_test_cross.fillna(X_train_cross.median(), inplace=True)

    # Compute class weights
    class_weights_array = class_weight.compute_class_weight(
        class_weight='balanced',
        classes=np.unique(y_train),
        y=y_train
    )
    class_weights = dict(zip(np.unique(y_train), class_weights_array))

    print(f"Train class distribution: {dict(zip(*np.unique(y_train, return_counts=True)))}")

    # ==================
    # Standardize features
    # ==================
    scaler_ts = StandardScaler()
    X_train_ts_flat = X_train_ts.reshape(-1, X_train_ts.shape[2])
    X_test_ts_flat = X_test_ts.reshape(-1, X_test_ts.shape[2])

    X_train_ts_scaled = scaler_ts.fit_transform(X_train_ts_flat).reshape(X_train_ts.shape)
    X_test_ts_scaled = scaler_ts.transform(X_test_ts_flat).reshape(X_test_ts.shape)

    scaler_cross = StandardScaler()
    X_train_cross_scaled = scaler_cross.fit_transform(X_train_cross)
    X_test_cross_scaled = scaler_cross.transform(X_test_cross)

    # ================
    # Build LSTM + cross-sectional model
    # ================

    input_ts = Input(shape=(X_train_ts_scaled.shape[1], X_train_ts_scaled.shape[2]), name='time_series_input')
    lstm_out = LSTM(64, return_sequences=False)(input_ts)
    lstm_out = Dropout(0.3)(lstm_out)

    input_cross = Input(shape=(X_train_cross_scaled.shape[1],), name='cross_sectional_input')

    concatenated = Concatenate()([lstm_out, input_cross])
    dense1 = Dense(32, activation='relu')(concatenated)
    output = Dense(1, activation='sigmoid')(dense1)

    model = Model(inputs=[input_ts, input_cross], outputs=output)

    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

    early_stop = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

    model.fit(
        [X_train_ts_scaled, X_train_cross_scaled], y_train,
        epochs=20,
        batch_size=16,
        validation_split=0.1,
        callbacks=[early_stop],
        verbose=0,
        class_weight=class_weights
    )

    # =========
    # Evaluate
    # =========
    print("X_test_ts_scaled shape:", X_test_ts_scaled.shape)
    print("Any NaNs in X_test_ts_scaled?", np.isnan(X_test_ts_scaled).any())
    print("X_test_cross_scaled shape:", X_test_cross_scaled.shape)
    print("Any NaNs in X_test_cross_scaled?", np.isnan(X_test_cross_scaled).any())

    y_pred_probs = model.predict([X_test_ts_scaled, X_test_cross_scaled]).flatten()
    print("Any NaNs in predictions?", np.isnan(y_pred_probs).any())

    y_pred = (y_pred_probs > 0.5).astype(int)

    if np.isnan(y_pred_probs).any():
        print("NaNs detected in prediction probabilities, skipping AUC calculation for this site.")
        auc = float('nan')
    elif len(np.unique(y_test)) == 2:
        auc = roc_auc_score(y_test, y_pred_probs)
    else:
        auc = float('nan')

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0


    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0

    print(f"Accuracy:  {acc:.3f}")
    print(f"Precision: {prec:.3f}")
    print(f"Recall:    {rec:.3f}")
    print(f"F1 Score:  {f1:.3f}")
    print(f"AUC:       {auc:.3f}")
    print(f"Negative Predictive Value (NPV): {npv:.2f}")
    print(f"Specificity: {specificity:.3f}")



    # =========
    # Permutation Importance
    # =========  # only compute if AUC is valid
    cross_importances = permutation_importance(
            model=model,
            X_ts=X_test_ts_scaled,
            X_cross=X_test_cross_scaled,
            y_true=y_test,
            cross_features=cross_sectional_features,
            metric_func=accuracy_score,
            baseline_score=acc
        )

    # print("Cross Sectional Feature Importances (acc drop):")
    # for feat, imp in sorted(cross_importances.items(), key=lambda x: -x[1]):
    #     print(f"{feat}: {imp:.4f}")


    X_ts_for_shap = X_test_ts_scaled[:100]  # or all: X_test_ts_scaled
    X_cross_for_shap = X_test_cross_scaled[:100]
    explainer = shap.GradientExplainer(model, [X_ts_for_shap, X_cross_for_shap])

    # Compute SHAP values for test longitudinal data (along with cross-sectional)
    shap_values = explainer.shap_values([X_test_ts_scaled, X_test_cross_scaled])
    shap_long = shap_values[0]  # shape: (samples, 2, 7)
    shap_cross = shap_values[1]  # SHAP values for cross-sectional input (shape: samples x features)


    # Average absolute SHAP values over samples and time steps for each longitudinal feature
    mean_abs_shap_long = np.mean(np.abs(shap_long), axis=(0,1))  # shape: (7,)
    mean_abs_shap_cross = np.mean(np.abs(shap_cross), axis=0)  # Average over samples



    # Store for averaging later across sites
    all_long_importances.append(mean_abs_shap_long)

    
    all_cross_importances.append(mean_abs_shap_cross)
    site_metrics.append((test_site, acc, prec,rec,npv,auc,specificity))




# =======================
# Report overall accuracy & AUC
# =======================
def mean_ci(data, confidence=0.95):
    a = np.array(data)
    n = len(a)
    mean = np.mean(a)
    sem = stats.sem(a)
    h = sem * stats.t.ppf((1 + confidence) / 2., n-1)
    return mean, mean - h, mean + h


def mean_ci_long(data, confidence=0.95):
    data = np.array(data)
    n = len(data)
    mean = np.mean(data).item()  # .item() converts 0-d array to float
    sem = np.std(data, ddof=1) / np.sqrt(n)
    h = sem * t.ppf((1 + confidence) / 2., n-1)
    lower = (mean - h).item()
    upper = (mean + h).item()
    return mean, lower, upper


print("\n===== Final Report =====")
for site, acc, prec, rec, npv, auc, spec in site_metrics:
    print(f"Site {site}: Accuracy = {acc:.3f}, Precision = {prec:.3f}, Recall = {rec:.3f}, NPV = {npv:.3f}, AUC = {auc:.3f}, Specificity = {spec:.3f}")

# Proper unpacking (7 elements per tuple)
acc_list = [acc for _, acc, _, _, _, _, _ in site_metrics]
prec_list = [prec for _, _, prec, _, _, _, _ in site_metrics]
rec_list = [rec for _, _, _, rec, _, _, _ in site_metrics]
npv_list = [npv for _, _, _, _, npv, _, _ in site_metrics]
auc_list = [auc for _, _, _, _, _, auc, _ in site_metrics if not np.isnan(auc)]
spec_list = [spec for _, _, _, _, _, _, spec in site_metrics]

avg_acc, acc_lower, acc_upper = mean_ci(acc_list)
avg_prec, prec_lower, prec_upper = mean_ci(prec_list)
avg_rec, rec_lower, rec_upper = mean_ci(rec_list)
avg_npv, npv_lower, npv_upper = mean_ci(npv_list)
avg_auc, auc_lower, auc_upper = mean_ci(auc_list)
avg_spec, spec_lower, spec_upper = mean_ci(spec_list)

print("\n===== LOSO Summary (Average ± 95% CI) =====")
print(f"Accuracy:                {avg_acc:.3f} [{acc_lower:.3f}, {acc_upper:.3f}]")
print(f"Precision (PPV):         {avg_prec:.3f} [{prec_lower:.3f}, {prec_upper:.3f}]")
print(f"Recall (Sensitivity):    {avg_rec:.3f} [{rec_lower:.3f}, {rec_upper:.3f}]")
print(f"NPV:                     {avg_npv:.3f} [{npv_lower:.3f}, {npv_upper:.3f}]")
print(f"AUC:                     {avg_auc:.3f} [{auc_lower:.3f}, {auc_upper:.3f}]")
print(f"Specificity:             {avg_spec:.3f} [{spec_lower:.3f}, {spec_upper:.3f}]")



all_cross_importances = np.array(all_cross_importances)  # shape: (n_folds, n_cross_features)

print("\n=== Average Cross-Sectional Feature Importances (SHAP) ===")
for i, feat in enumerate(cross_sectional_features):  # cross-sectional feature names
    mean, lower, upper = mean_ci_long(all_cross_importances[:, i])
    print(f"{feat}: {mean:.4f} (95% CI: [{lower:.4f}, {upper:.4f}])")

all_long_importances = np.array(all_long_importances)  # shape: (n_folds, n_features)

print("\n=== Average Longitudinal Feature Importances (SHAP) ===")
for i, feat in enumerate(features_baseline):  # use your longitudinal feature names
    mean, lower, upper = mean_ci_long(all_long_importances[:, i])
    print(f"{feat}: {mean:.4f} (95% CI: [{lower:.4f}, {upper:.4f}])")




# ===== Final Report =====
# Site 21: Accuracy = 0.867, Precision = 0.241, Recall = 0.500, NPV = 0.963, AUC = 0.767, Specificity = 0.892
# Site 11: Accuracy = 0.764, Precision = 0.083, Recall = 1.000, NPV = 1.000, AUC = 0.998, Specificity = 0.759
# Site 4: Accuracy = 0.719, Precision = 0.089, Recall = 0.500, NPV = 0.965, AUC = 0.683, Specificity = 0.730
# Site 5: Accuracy = 0.900, Precision = 0.231, Recall = 0.600, NPV = 0.981, AUC = 0.748, Specificity = 0.913
# Site 6: Accuracy = 0.856, Precision = 0.079, Recall = 0.600, NPV = 0.991, AUC = 0.760, Specificity = 0.861
# Site 20: Accuracy = 0.772, Precision = 0.220, Recall = 0.769, NPV = 0.976, AUC = 0.852, Specificity = 0.772
# Site 1: Accuracy = 0.709, Precision = 0.125, Recall = 0.667, NPV = 0.972, AUC = 0.753, Specificity = 0.711
# Site 18: Accuracy = 0.823, Precision = 0.208, Recall = 0.833, NPV = 0.989, AUC = 0.947, Specificity = 0.822
# Site 3: Accuracy = 0.744, Precision = 0.025, Recall = 0.250, NPV = 0.976, AUC = 0.677, Specificity = 0.756
# Site 12: Accuracy = 0.861, Precision = 0.222, Recall = 0.750, NPV = 0.986, AUC = 0.814, Specificity = 0.866
# Site 14: Accuracy = 0.934, Precision = 0.200, Recall = 0.800, NPV = 0.996, AUC = 0.933, Specificity = 0.937
# Site 10: Accuracy = 0.831, Precision = 0.294, Recall = 0.625, NPV = 0.958, AUC = 0.807, Specificity = 0.851
# Site 16: Accuracy = 0.943, Precision = 0.200, Recall = 0.500, NPV = 0.988, AUC = 0.938, Specificity = 0.953
# Site 13: Accuracy = 0.751, Precision = 0.088, Recall = 1.000, NPV = 1.000, AUC = 0.941, Specificity = 0.745
# Site 9: Accuracy = 0.784, Precision = 0.171, Recall = 1.000, NPV = 1.000, AUC = 0.921, Specificity = 0.773
# Site 2: Accuracy = 0.877, Precision = 0.040, Recall = 0.250, NPV = 0.985, AUC = 0.735, Specificity = 0.888
# Site 15: Accuracy = 0.699, Precision = 0.048, Recall = 1.000, NPV = 1.000, AUC = 0.779, Specificity = 0.695
# Site 19: Accuracy = 0.785, Precision = 0.111, Recall = 0.714, NPV = 0.987, AUC = 0.843, Specificity = 0.787
# Site 8: Accuracy = 0.806, Precision = 0.059, Recall = 0.333, NPV = 0.974, AUC = 0.593, Specificity = 0.822
# Site 17: Accuracy = 0.923, Precision = 0.100, Recall = 1.000, NPV = 1.000, AUC = 0.987, Specificity = 0.922
# Site 7: Accuracy = 0.882, Precision = 0.111, Recall = 1.000, NPV = 1.000, AUC = 1.000, Specificity = 0.881
# Site 22: Accuracy = 0.875, Precision = 0.000, Recall = 0.000, NPV = 1.000, AUC = nan, Specificity = 0.875

# ===== LOSO Summary (Average ± 95% CI) =====
# Accuracy:                0.823 [0.790, 0.856]
# Precision (PPV):         0.134 [0.098, 0.170]
# Recall (Sensitivity):    0.668 [0.541, 0.795]
# NPV:                     0.986 [0.980, 0.992]
# AUC:                     0.832 [0.779, 0.885]
# Specificity:             0.828 [0.794, 0.862]

# === Average Cross-Sectional Feature Importances (SHAP) ===
# rel_family_id: 0.0017 (95% CI: [0.0014, 0.0021])
# demo_sex_v2: 0.0716 (95% CI: [0.0637, 0.0795])
# race_ethnicity: 0.0282 (95% CI: [0.0216, 0.0347])
# acs_raked_propensity_score: 0.0095 (95% CI: [0.0077, 0.0114])
# speechdelays: 0.0110 (95% CI: [0.0075, 0.0145])
# motordelays: 0.0101 (95% CI: [0.0082, 0.0120])
# fam_history_8_yes_no: 0.0102 (95% CI: [0.0081, 0.0124])

# === Average Longitudinal Feature Importances (SHAP) ===
# interview_age.baseline_year_1_arm_1: 0.0145 (95% CI: [0.0125, 0.0165])
# KSADSintern.baseline_year_1_arm_1: 0.0435 (95% CI: [0.0382, 0.0488])
# nihtbx_cryst_agecorrected.baseline_year_1_arm_1: 0.0287 (95% CI: [0.0246, 0.0327])
# ACEs.baseline_year_1_arm_1: 0.0428 (95% CI: [0.0396, 0.0460])
# avgPFCthick_QA.baseline_year_1_arm_1: 0.0148 (95% CI: [0.0122, 0.0175])
# rsfmri_c_ngd_cgc_ngd_cgc_QA.baseline_year_1_arm_1: 0.0117 (95% CI: [0.0089, 0.0145])
# rsfmri_c_ngd_dt_ngd_dt_QA.baseline_year_1_arm_1: 0.0166 (95% CI: [0.0143, 0.0190])